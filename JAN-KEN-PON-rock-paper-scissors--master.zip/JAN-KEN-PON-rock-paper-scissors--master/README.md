# Project skeleton

This is a project skeleton that is used to start in Video #1.

https://youtu.be/xVcVbCLmKew

It is not possible to launch it (yet). For the first versions 
of working games check out code in the next lessons.# JAN-KEN-PON-rock-paper-scissors-
